# WINDOWS RDP FREE WITH ACTION
*uhh do you want a free rdp windows server 2019 :?*
*OK it really easy with github :VVVVVVVV*
*OK,Let's start*


# *follow this step*

- *click the Fork in the left corner(UHHH MY ENGLISH IS SO BAD) to stolen this repo :))*
- *Then go to the ngrok.com and sign in to this (or regster)*

- *Next go to the Settings and click to Secrets -> New repository secret -> type NGROK_AUTH_TOKEN in the name and go to https://dashboard.ngrok.com/get-started/your-authtoken*
  *to get your auth token and paste to value -> Add secret*

- *okkkkkk now go tho the Actions -> CI(in your right 1st) -> Run workflow - F5 -> click to CI(in your middle) -> build -> (when it to the final step ) click to "Connect to your RDP"*
  *and copy the ip,..etc.. to your rdp apps*

- *enjoy your free rdp server (windows server 2019) it max to 6h*

# *Note in 6/9/21*
- *Now Updated The Action File To Fix Bug*

- *Sometime i connect to u rdp so please don't kick me out :( i want try but my acc is *bug* or something like this so i want try :(*
- *So if it crack start *build* again
- *It is my first tool so thank u so much to fork and try it :)* 
# LET'S ADD SOME TAG TO ANYBODY KNOW IT :)
- ***
- cách tạo vps miễn phí.
Cáo tạo vps free. 
tao vps khong can the visa
tao vps moi nhat
huong dan tao vps no card 2020
cách tạo vps mới nhất
hướng dẫn tạo vps miễn phí
cách tạo vps mới nhất
#vpsfree
tag: vps,vps free,cách tạo vps free,cách tạo vps miễn phí,cách tạo vps không cần visa,how to creat vps no card,cách tạo vps no visa,vps hosting,virtual private server,hosting,free vps,free vps trial,free vps trial 1 month,free vps linux,free vps 2019,free vps server linux,tạo vps free mới nhất,tạo vps không cần visa và sđt,cách tạo vps không ần visa 2020,vps miễn phí,vps amzon,vps free visa,free visa,vps free no card,vps free new,cách tạo vps ram 1gb
#reg
#freerdp
***
